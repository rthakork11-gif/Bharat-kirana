package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.Bill
import com.example.data.BillItem
import com.example.data.Product
import com.example.ui.KiranaViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.util.PdfHelper
import com.example.util.PrinterHelper
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: KiranaViewModel = viewModel(factory = KiranaViewModel.Factory)
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

            MyApplicationTheme(darkTheme = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    KiranaAppScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KiranaAppScreen(viewModel: KiranaViewModel) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    // Dialog state controllers
    var showAddEditProductDialog by remember { mutableStateOf(false) }
    var billJustSaved by remember { mutableStateOf<Bill?>(null) }
    var selectedViewBill by remember { mutableStateOf<Bill?>(null) }

    // Toast message handling
    LaunchedEffect(statusMessage) {
        if (statusMessage != null) {
            // Self-dismissing info banner
            kotlinx.coroutines.delay(2500)
            viewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Custom Drawn Mini Store Logo
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    MaterialTheme.colorScheme.primaryContainer,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Storefront,
                                contentDescription = "Logo",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                "भारत किराना",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            )
                            Text(
                                "Bharat Kirana Billing",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                },
                actions = {
                    // Dark Mode Switch
                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("dark_mode_toggle")
                    ) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                            contentDescription = "Toggle Theme",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
            )
        },
        bottomBar = {
            // Elegant bilingual bottom navigation bar
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp),
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { viewModel.setTab(0) },
                    icon = { Icon(Icons.Rounded.ReceiptLong, contentDescription = "Billing") },
                    label = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("बिलिंग", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Billing", fontSize = 9.sp)
                        }
                    }
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = { viewModel.setTab(1) },
                    icon = { Icon(Icons.Rounded.Inventory, contentDescription = "Stock") },
                    label = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("स्टॉक", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Stock", fontSize = 9.sp)
                        }
                    }
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { viewModel.setTab(2) },
                    icon = { Icon(Icons.Rounded.BarChart, contentDescription = "Reports") },
                    label = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("रिपोर्ट्स", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Reports", fontSize = 9.sp)
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            if (currentTab == 1) {
                // Stock Panel: Floating Action Button to add product
                ExtendedFloatingActionButton(
                    text = {
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("नया सामान", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("New Item", fontSize = 9.sp)
                        }
                    },
                    icon = { Icon(Icons.Filled.Add, contentDescription = "Add Product") },
                    onClick = {
                        viewModel.startAddingProduct()
                        showAddEditProductDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = MaterialTheme.colorScheme.onSecondary
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Display active panel layout
            when (currentTab) {
                0 -> BillingTabContent(viewModel = viewModel, onBillSaved = { bill -> billJustSaved = bill })
                1 -> StockTabContent(
                    viewModel = viewModel,
                    onEditRequest = {
                        showAddEditProductDialog = true
                    }
                )
                2 -> ReportsTabContent(viewModel = viewModel, onViewBillDetails = { bill -> selectedViewBill = bill })
            }

            // Top Status Banner Notification (Self-Dismissing)
            AnimatedVisibility(
                visible = statusMessage != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.inverseSurface,
                        contentColor = MaterialTheme.colorScheme.inverseOnSurface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Text(
                        text = statusMessage ?: "",
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Add / Edit Product Modal Dialog
            if (showAddEditProductDialog) {
                val editingProduct by viewModel.editingProduct.collectAsStateWithLifecycle()
                AddEditProductDialog(
                    viewModel = viewModel,
                    product = editingProduct,
                    onDismiss = {
                        showAddEditProductDialog = false
                        viewModel.cancelProductEdit()
                    }
                )
            }

            // Bill Saved - Thermal Printer & Sharing Success Screen
            if (billJustSaved != null) {
                BillSuccessOptionsDialog(
                    viewModel = viewModel,
                    bill = billJustSaved!!,
                    onDismiss = { billJustSaved = null }
                )
            }

            // View Invoice Details Dialog
            if (selectedViewBill != null) {
                BillDetailsDialog(
                    viewModel = viewModel,
                    bill = selectedViewBill!!,
                    onDismiss = { selectedViewBill = null }
                )
            }
        }
    }
}

// ==========================================
// BILLING PANE TAB CONTENT
// ==========================================
@Composable
fun BillingTabContent(
    viewModel: KiranaViewModel,
    onBillSaved: (Bill) -> Unit
) {
    val customerName by viewModel.customerName.collectAsStateWithLifecycle()
    val customerMobile by viewModel.customerMobile.collectAsStateWithLifecycle()
    val billingSearchQuery by viewModel.billingSearchQuery.collectAsStateWithLifecycle()
    val billingSelectedCategory by viewModel.billingSelectedCategory.collectAsStateWithLifecycle()
    val filteredProducts by viewModel.filteredBillingProducts.collectAsStateWithLifecycle()
    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()
    val enteredPrice by viewModel.enteredPrice.collectAsStateWithLifecycle()
    val enteredQuantity by viewModel.enteredQuantity.collectAsStateWithLifecycle()
    val enteredTotal by viewModel.enteredTotal.collectAsStateWithLifecycle()
    val billItems by viewModel.billItems.collectAsStateWithLifecycle()
    val billGrandTotal by viewModel.billGrandTotal.collectAsStateWithLifecycle()

    // Categories list for scroll filter
    val categories = listOf("All", "मावा", "Cigarette / Bidi", "Biscuit", "Grocery", "Soap", "Toothpaste", "Chips")

    // Dropdown picker expansion state
    var isProductDropdownExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Shop Greeting Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            "नया बिल बनाएं",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Text(
                            "Create Fresh Bill Invoice",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    // Simple UTC/Real Date Text
                    val todayStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())
                    Text(
                        text = todayStr,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    )
                }
            }
        }

        // 2. Customer Information Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "ग्राहक विवरण (Customer Details)",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { viewModel.updateCustomerName(it) },
                            label = { Text("नाम (Customer Name)") },
                            leadingIcon = { Icon(Icons.Outlined.Badge, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("customer_name_input"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = customerMobile,
                            onValueChange = { viewModel.updateCustomerMobile(it) },
                            label = { Text("मोबाइल (Mobile No)") },
                            leadingIcon = { Icon(Icons.Outlined.Phone, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("customer_mobile_input"),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }

        // 3. Product Picker and Quantity Input Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.ShoppingBag,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "सामान चुनें (Product Selection)",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    // A: Horizontal category scroll chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(categories) { cat ->
                            val isSelected = billingSelectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.selectBillingCategory(cat) },
                                label = { Text(cat) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }

                    // B: Dropdown Picker List with Internal Search Box
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = selectedProduct?.name ?: "सामान की सूची खोलें (Tap to Pick Product)",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("सामान चुनें (Select Item)") },
                            trailingIcon = {
                                Icon(
                                    imageVector = if (isProductDropdownExpanded) Icons.Filled.ArrowDropUp else Icons.Filled.ArrowDropDown,
                                    contentDescription = "Expand list"
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("product_dropdown"),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Invisible clickable overlay to capture touch inputs cleanly without popping up keyboard
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .clickable { isProductDropdownExpanded = true }
                        )

                        DropdownMenu(
                            expanded = isProductDropdownExpanded,
                            onDismissRequest = { isProductDropdownExpanded = false },
                            modifier = Modifier
                                .fillMaxWidth(0.9f)
                                .heightIn(max = 300.dp)
                        ) {
                            // Search box inside Dropdown list
                            OutlinedTextField(
                                value = billingSearchQuery,
                                onValueChange = { viewModel.updateBillingSearch(it) },
                                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                placeholder = { Text("खोजें (Search product name)...", fontSize = 13.sp) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                singleLine = true,
                                shape = RoundedCornerShape(8.dp)
                            )

                            DropdownMenuItem(
                                text = { Text("-- कोई नहीं (Clear Selection) --", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    viewModel.selectProduct(null)
                                    isProductDropdownExpanded = false
                                }
                            )

                            if (filteredProducts.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("कोई सामान नहीं मिला (No product found)") },
                                    onClick = {},
                                    enabled = false
                                )
                            } else {
                                filteredProducts.forEach { prod ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(prod.name, fontWeight = FontWeight.Bold)
                                                    Text(prod.category, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                                Text(
                                                    "₹${prod.price} | Stock: ${prod.stock}",
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        },
                                        onClick = {
                                            viewModel.selectProduct(prod)
                                            isProductDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // C: Dynamic Price, Qty and Row Calculation
                    if (selectedProduct != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .border(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("प्रति इकाई कीमत (Unit Rate)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    "₹${String.format(Locale.getDefault(), "%.2f", enteredPrice)}",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }

                            // Interactive quantity adjust controls
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("मात्रा (Quantity)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(top = 4.dp)
                                ) {
                                    FilledIconButton(
                                        onClick = { viewModel.updateEnteredQuantity(enteredQuantity - 1) },
                                        modifier = Modifier.size(32.dp),
                                        colors = IconButtonDefaults.filledIconButtonColors(
                                            containerColor = MaterialTheme.colorScheme.secondary
                                        )
                                    ) {
                                        Icon(Icons.Filled.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                                    }

                                    Text(
                                        text = "$enteredQuantity",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        modifier = Modifier.widthIn(min = 24.dp),
                                        textAlign = TextAlign.Center
                                    )

                                    FilledIconButton(
                                        onClick = { viewModel.updateEnteredQuantity(enteredQuantity + 1) },
                                        modifier = Modifier.size(32.dp),
                                        colors = IconButtonDefaults.filledIconButtonColors(
                                            containerColor = MaterialTheme.colorScheme.secondary
                                        )
                                    ) {
                                        Icon(Icons.Filled.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            // Dynamic Total calculation output: price * quantity
                            Column(horizontalAlignment = Alignment.End) {
                                Text("योग (Item Total)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    "₹${String.format(Locale.getDefault(), "%.2f", enteredTotal)}",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                )
                            }
                        }
                    }

                    // D: Add Item Action Button
                    Button(
                        onClick = { viewModel.addBillItem() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("add_item_button"),
                        enabled = selectedProduct != null,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.AddShoppingCart, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "सामान बिल में जोड़ें (Add to Bill)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        // 4. Cart List Section (ListView equivalent)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.ListAlt,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "बिल में जुड़े हुए सामान (Invoice Items)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // Count bubble
                Box(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primary, CircleShape)
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "${billItems.size} Items",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (billItems.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ProductionQuantityLimits,
                            contentDescription = "Empty Basket",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "बिल में कोई सामान नहीं है",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Please select a product and tap Add to Bill",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        } else {
            items(billItems) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                item.productName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(
                                modifier = Modifier.padding(top = 2.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    item.category,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    "Rate: ₹${item.price}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    "Qty: ${item.quantity}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                "₹${String.format(Locale.getDefault(), "%.1f", item.total)}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )

                            IconButton(
                                onClick = { viewModel.removeBillItem(item) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteOutline,
                                    contentDescription = "Remove item",
                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Grand Total and Bill Checkout card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                ),
                border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "कुल योग (Grand Total)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                            Text(
                                "Total payable including all items",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                )
                            )
                        }

                        Text(
                            "₹${String.format(Locale.getDefault(), "%.2f", billGrandTotal)}",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    Divider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))

                    // Billing control Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Clear current bill
                        OutlinedButton(
                            onClick = { viewModel.clearBill() },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("clear_bill_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
                            enabled = billItems.isNotEmpty() || customerName.isNotEmpty()
                        ) {
                            Icon(Icons.Filled.ClearAll, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("साफ़ करें (Clear)", fontWeight = FontWeight.Bold)
                        }

                        // Save current bill & open trigger PDF flow
                        Button(
                            onClick = {
                                viewModel.saveBill(onSaved = { savedBill ->
                                    onBillSaved(savedBill)
                                })
                            },
                            modifier = Modifier
                                .weight(1.5f)
                                .height(48.dp)
                                .testTag("save_bill_button"),
                            shape = RoundedCornerShape(12.dp),
                            enabled = billItems.isNotEmpty()
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("सुरक्षित करें (Save Bill)", fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// STOCK MANAGEMENT TAB CONTENT
// ==========================================
@Composable
fun StockTabContent(
    viewModel: KiranaViewModel,
    onEditRequest: () -> Unit
) {
    val stockSearchQuery by viewModel.stockSearchQuery.collectAsStateWithLifecycle()
    val filteredStockProducts by viewModel.filteredStockProducts.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Search bar
        OutlinedTextField(
            value = stockSearchQuery,
            onValueChange = { viewModel.updateStockSearch(it) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search stock") },
            trailingIcon = {
                if (stockSearchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateStockSearch("") }) {
                        Icon(Icons.Filled.Close, contentDescription = "Clear search")
                    }
                }
            },
            placeholder = { Text("सामान या श्रेणी खोजें (Search Name or Category)...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "स्टॉक सूची (Product Inventory)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                "कुल सामान: ${filteredStockProducts.size}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (filteredStockProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.Inventory,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        "कोई सामान नहीं मिला!",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "Try changing search query or tap '+' to add item.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredStockProducts) { product ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        product.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        product.category,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .background(
                                                MaterialTheme.colorScheme.primaryContainer,
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }

                                Row(
                                    modifier = Modifier.padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Text(
                                        "कीमत (Price): ₹${product.price}",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    // Stock level alert representation
                                    val isLowStock = product.stock <= 10
                                    Text(
                                        text = "स्टॉक (Stock): ${product.stock}",
                                        fontSize = 13.sp,
                                        fontWeight = if (isLowStock) FontWeight.ExtraBold else FontWeight.SemiBold,
                                        color = if (isLowStock) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                // Edit
                                IconButton(
                                    onClick = {
                                        viewModel.startEditingProduct(product)
                                        onEditRequest()
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Edit,
                                        contentDescription = "Edit product",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }

                                // Delete
                                var showConfirmDelete by remember { mutableStateOf(false) }
                                IconButton(
                                    onClick = { showConfirmDelete = true }
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = "Delete product",
                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                                    )
                                }

                                if (showConfirmDelete) {
                                    AlertDialog(
                                        onDismissRequest = { showConfirmDelete = false },
                                        title = { Text("सामान हटाएं? (Delete Item?)") },
                                        text = { Text("क्या आप सचमुच '${product.name}' को स्टॉक से हटाना चाहते हैं?") },
                                        confirmButton = {
                                            TextButton(
                                                onClick = {
                                                    viewModel.deleteProduct(product)
                                                    showConfirmDelete = false
                                                }
                                            ) {
                                                Text("हाँ, हटाएं (Yes, Delete)", color = MaterialTheme.colorScheme.error)
                                            }
                                        },
                                        dismissButton = {
                                            TextButton(onClick = { showConfirmDelete = false }) {
                                                Text("नहीं (No)")
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// REPORTS & HISTORY TAB CONTENT
// ==========================================
@Composable
fun ReportsTabContent(
    viewModel: KiranaViewModel,
    onViewBillDetails: (Bill) -> Unit
) {
    val allBills by viewModel.allBills.collectAsStateWithLifecycle()

    // Sales metrics calculations
    val calendar = Calendar.getInstance()
    
    val todayStart = remember(allBills) {
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        calendar.timeInMillis
    }

    val monthStart = remember(allBills) {
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.timeInMillis
    }

    val dailyTotal = remember(allBills) {
        allBills.filter { it.timestamp >= todayStart }.sumOf { it.grandTotal }
    }

    val monthlyTotal = remember(allBills) {
        allBills.filter { it.timestamp >= monthStart }.sumOf { it.grandTotal }
    }

    val dailyCount = remember(allBills) {
        allBills.filter { it.timestamp >= todayStart }.size
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Title
        item {
            Text(
                "बिक्री रिपोर्ट (Sales Analytics Dashboard)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Metrics Grid Layout equivalent using Card Rows
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Metric 1: Today's sales
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "आज की बिक्री (Daily Sales)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                        Text(
                            "₹${String.format(Locale.getDefault(), "%.0f", dailyTotal)}",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "कुल बिल: $dailyCount",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                        )
                    }
                }

                // Metric 2: Monthly sales
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "इस महीने (Monthly Sales)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                        )
                        Text(
                            "₹${String.format(Locale.getDefault(), "%.0f", monthlyTotal)}",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "कुल बिल: ${allBills.size}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // 3. Transactions List Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "बिल इतिहास (Saved Invoice Records)",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        }

        if (allBills.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.ReceiptLong,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "कोई बिल इतिहास नहीं मिला",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            "Invoices saved in Billing Tab will show here.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    }
                }
            }
        } else {
            items(allBills) { bill ->
                val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(bill.timestamp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onViewBillDetails(bill) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "बिल No: #${bill.id}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    bill.customerName,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                dateStr,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "₹${String.format(Locale.getDefault(), "%.1f", bill.grandTotal)}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Icon(Icons.Filled.ChevronRight, contentDescription = "View receipt", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// MODAL DIALOGS AND HELPER COMPOSABLES
// ==========================================

// 1. ADD / EDIT PRODUCT DIALOG
@Composable
fun AddEditProductDialog(
    viewModel: KiranaViewModel,
    product: Product?,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var category by remember { mutableStateOf(product?.category ?: "Grocery") }
    var priceStr by remember { mutableStateOf(product?.price?.toString() ?: "") }
    var stockStr by remember { mutableStateOf(product?.stock?.toString() ?: "100") }

    val categories = listOf("मावा", "Cigarette / Bidi", "Biscuit", "Grocery", "Soap", "Toothpaste", "Chips")
    var categoryDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (product != null) "सामान बदलें (Edit Product)" else "नया सामान जोड़ें (Add Product)",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Product Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("सामान का नाम (Product Name)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                // Category dropdown selection
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("श्रेणी (Category)") },
                        trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { categoryDropdownExpanded = true },
                        shape = RoundedCornerShape(8.dp)
                    )

                    DropdownMenu(
                        expanded = categoryDropdownExpanded,
                        onDismissRequest = { categoryDropdownExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.75f)
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    category = cat
                                    categoryDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Price Row & Stock Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text("कीमत (Price ₹)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = stockStr,
                        onValueChange = { stockStr = it },
                        label = { Text("स्टॉक मात्रा (Stock)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val price = priceStr.toDoubleOrNull() ?: 0.0
                    val stock = stockStr.toIntOrNull() ?: 0
                    viewModel.saveProduct(name, category, price, stock)
                    onDismiss()
                }
            ) {
                Text("सहेजें (Save)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें (Cancel)")
            }
        }
    )
}

// 2. SAVE BILL SUCCESS DIALOG (PDF sharing, WhatsApp and Thermal receipt simulator)
@Composable
fun BillSuccessOptionsDialog(
    viewModel: KiranaViewModel,
    bill: Bill,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val items = remember(bill) { viewModel.getBillItemsList(bill) }

    // Generate PDF cache instantly for sharing operations
    val pdfFile = remember(bill) { PdfHelper.generateBillPdf(context, bill, items) }

    // Thermal Receipt monospaced representation
    val receiptText = remember(bill) { PrinterHelper.buildThermalReceiptText(bill, items) }

    // Bluetooth Printer scanning selector
    var showBluetoothPrintSetup by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.92f)
                .shadow(12.dp, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header Banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Success",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("बिल सहेजा गया!", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
                            Text("Invoice saved successfully", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp))

                // Scrollable content showing Simulated receipt roll
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(
                            color = if (MaterialTheme.colorScheme.surface == Color(0xFF0F172A) || MaterialTheme.colorScheme.surface == Color(0xFF1E293B))
                                Color(0xFF070F1E) else Color(0xFFF1F5F9),
                            shape = RoundedCornerShape(8.dp)
                        )
                        .border(
                            BorderStroke(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(12.dp)
                ) {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        item {
                            // Thermal printer receipt paper visualization layout
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color.LightGray)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp)
                                ) {
                                    // Custom Jagged Edge Simulator
                                    Text(
                                        text = receiptText,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 11.sp,
                                        color = Color.Black,
                                        lineHeight = 15.sp
                                    )
                                    
                                    // Simple Mock Barcode representing Bill ID
                                    Canvas(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(30.dp)
                                            .padding(top = 10.dp)
                                    ) {
                                        val barColor = Color.DarkGray
                                        var currentX = 10f
                                        val steps = listOf(3, 1, 4, 1, 2, 3, 1, 4, 2, 2, 1, 3, 4, 1, 1, 2)
                                        while (currentX < size.width - 20) {
                                            for (step in steps) {
                                                drawRect(
                                                    color = barColor,
                                                    topLeft = androidx.compose.ui.geometry.Offset(currentX, 0f),
                                                    size = androidx.compose.ui.geometry.Size(step * 1.5f, size.height)
                                                )
                                                currentX += (step * 3f)
                                            }
                                        }
                                    }
                                    Text(
                                        text = "* KIRANABILL-${bill.id} *",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp,
                                        color = Color.Black,
                                        modifier = Modifier.fillMaxWidth(),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Actions Layout: Sharing and Real Printing
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Action 1: WhatsApp PDF Share
                    Button(
                        onClick = {
                            if (pdfFile != null) {
                                PdfHelper.sharePdfViaWhatsApp(context, pdfFile)
                            } else {
                                viewModel.showMessage("PDF उत्पन्न करने में विफलता!")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)), // WhatsApp official green branding color
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = "WhatsApp")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("व्हाट्सएप पर शेयर (WhatsApp Share)", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Action 2: Standard PDF share chooser
                        OutlinedButton(
                            onClick = {
                                if (pdfFile != null) {
                                    PdfHelper.sharePdf(context, pdfFile)
                                } else {
                                    viewModel.showMessage("PDF उत्पन्न करने में विफलता!")
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Outlined.PictureAsPdf, contentDescription = "PDF")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PDF देखें (View)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }

                        // Action 3: Bluetooth Thermal print trigger
                        Button(
                            onClick = { showBluetoothPrintSetup = true },
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Filled.Print, contentDescription = "Print")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("प्रिंट करें (Print Receipt)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }

    if (showBluetoothPrintSetup) {
        BluetoothPrintSelectorDialog(
            viewModel = viewModel,
            bill = bill,
            items = items,
            onDismiss = { showBluetoothPrintSetup = false }
        )
    }
}

// 3. BLUETOOTH PRINTER SELECTOR & DRIVER CONNECTION POPUP
@Composable
fun BluetoothPrintSelectorDialog(
    viewModel: KiranaViewModel,
    bill: Bill,
    items: List<BillItem>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var selectedPrinter by remember { mutableStateOf<BluetoothDevice?>(null) }
    var bluetoothPermissionGranted by remember { mutableStateOf(false) }
    var printStatusMessage by remember { mutableStateOf("") }
    var isPrintingInProgress by remember { mutableStateOf(false) }

    // Launcher for bluetooth permission prompt
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions[Manifest.permission.BLUETOOTH_CONNECT] == true
        } else {
            true // Automatic grant on older API versions via manifest declaration
        }
        bluetoothPermissionGranted = granted
        if (granted) {
            pairedDevices = PrinterHelper.getPairedDevices()
        } else {
            printStatusMessage = "ब्लूटूथ अनुमति अस्वीकृत! (Bluetooth permission denied)"
        }
    }

    // Check permissions and scan initially
    LaunchedEffect(Unit) {
        val permissionCheck = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        if (permissionCheck) {
            bluetoothPermissionGranted = true
            pairedDevices = PrinterHelper.getPairedDevices()
        } else {
            // Request Android 12 Bluetooth runtime permissions
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                permissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_SCAN
                    )
                )
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("थर्मल प्रिंटर से कनेक्ट करें", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Bluetooth thermal printer connection", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!bluetoothPermissionGranted) {
                    Text(
                        "ब्लूटूथ प्रिंटर को खोजने के लिए ब्लूटूथ अनुमति आवश्यक है। कृपया अनुमति प्रदान करें।",
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp
                    )
                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.BLUETOOTH_CONNECT,
                                        Manifest.permission.BLUETOOTH_SCAN
                                    )
                                )
                            }
                        }
                    ) {
                        Text("अनुमति दें (Grant Permission)")
                    }
                } else if (pairedDevices.isEmpty()) {
                    Text(
                        "कोई पेयर किया हुआ ब्लूटूथ थर्मल प्रिंटर नहीं मिला!\n\nसुझाव:\n1. मोबाइल ब्लूटूथ सेटिंग्स में जाएँ।\n2. 'Bluetooth Printer' या '58mm Printer' को सर्च कर पेयर (Pair) करें (डिफ़ॉल्ट पिन 0000 या 1234)।\n3. इसके बाद यहाँ फिर से खोलें।",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text("पेयर किये हुए प्रिंटर की सूची चुनें (Select Paired Printer):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 180.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(pairedDevices) { device ->
                            val deviceName = try { device.name ?: "Unknown Printer" } catch (e: SecurityException) { "Printer Dev" }
                            val isSelected = selectedPrinter == device
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedPrinter = device },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(deviceName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(device.address, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }

                if (printStatusMessage.isNotEmpty()) {
                    Text(
                        text = printStatusMessage,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (printStatusMessage.contains("सफल")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                    )
                }

                if (isPrintingInProgress) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Text("प्रिंटर को डेटा भेजा जा रहा है...", fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedPrinter == null) {
                        printStatusMessage = "कृपया पहले कोई प्रिंटर चुनें! (Choose printer first)"
                        return@Button
                    }
                    isPrintingInProgress = true
                    printStatusMessage = "प्रिंट हो रहा है (Connecting...)"
                    PrinterHelper.printToBluetoothDevice(
                        device = selectedPrinter!!,
                        bill = bill,
                        items = items
                    ) { success, msg ->
                        isPrintingInProgress = false
                        printStatusMessage = msg
                        if (success) {
                            viewModel.showMessage("सफलतापूर्वक प्रिंट किया गया!")
                        }
                    }
                },
                enabled = selectedPrinter != null && !isPrintingInProgress
            ) {
                Icon(Icons.Filled.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("प्रिंट शुरू करें (Print)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द (Close)")
            }
        }
    )
}

// 4. HISTORIC BILL DETAILS DISPLAY DIALOG
@Composable
fun BillDetailsDialog(
    viewModel: KiranaViewModel,
    bill: Bill,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val items = remember(bill) { viewModel.getBillItemsList(bill) }
    val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(bill.timestamp))
    val pdfFile = remember(bill) { PdfHelper.generateBillPdf(context, bill, items) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("बिल विवरण (Invoice Receipt)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Bill ID: #${bill.id}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = "Close")
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp))

                // Customer info card inside details
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("ग्राहक (Customer): ${bill.customerName}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        if (bill.customerMobile.isNotEmpty()) {
                            Text("मोबाइल (Mobile): +91-${bill.customerMobile}", fontSize = 12.sp)
                        }
                        Text("दिनांक (Date): $dateStr", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("सामान की सूची (Purchased Items):", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                // List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(items) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.02f), RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.productName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Rate: ₹${item.price} | Qty: ${item.quantity}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("₹${item.total}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        }
                    }
                }

                Divider(modifier = Modifier.padding(vertical = 10.dp))

                // Grand Total Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("कुल राशि (Total Amount):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(
                        "₹${String.format(Locale.getDefault(), "%.2f", bill.grandTotal)}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Share Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            if (pdfFile != null) {
                                PdfHelper.sharePdf(context, pdfFile)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Outlined.Share, contentDescription = "Share PDF", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("शेयर PDF", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            if (pdfFile != null) {
                                PdfHelper.sharePdfViaWhatsApp(context, pdfFile)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF128C7E)),
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = "WhatsApp", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("व्हाट्सएप", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
