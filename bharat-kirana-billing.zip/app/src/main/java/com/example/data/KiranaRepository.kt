package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class KiranaRepository(
    private val productDao: ProductDao,
    private val billDao: BillDao
) {
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()
    val allBills: Flow<List<Bill>> = billDao.getAllBills()

    fun searchProducts(query: String): Flow<List<Product>> {
        return productDao.searchProducts(query)
    }

    suspend fun insertProduct(product: Product): Long {
        return productDao.insertProduct(product)
    }

    suspend fun updateProduct(product: Product) {
        productDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: Product) {
        productDao.deleteProduct(product)
    }

    suspend fun insertBill(bill: Bill): Long {
        return billDao.insertBill(bill)
    }

    suspend fun deleteBill(bill: Bill) {
        billDao.deleteBill(bill)
    }

    suspend fun prepopulateIfEmpty() {
        val currentProducts = productDao.getAllProducts().first()
        if (currentProducts.isEmpty()) {
            val initialProducts = listOf(
                // मावा
                Product(name = "Safed Mawa", price = 6.0, category = "मावा", stock = 100),
                Product(name = "Peela Mawa", price = 5.0, category = "मावा", stock = 100),
                Product(name = "Vimal", price = 5.0, category = "मावा", stock = 200),
                Product(name = "Silver", price = 5.0, category = "मावा", stock = 150),
                Product(name = "Kalkatti", price = 5.0, category = "मावा", stock = 100),
                Product(name = "Budhalal Kalkatti", price = 8.0, category = "मावा", stock = 100),

                // Cigarette / Bidi
                Product(name = "Gold Flake Cigarette", price = 5.0, category = "Cigarette / Bidi", stock = 250),
                Product(name = "Bhumi Special Bidi", price = 25.0, category = "Cigarette / Bidi", stock = 80),
                Product(name = "Telephone Special", price = 30.0, category = "Cigarette / Bidi", stock = 70),

                // Biscuit
                Product(name = "Parle G", price = 5.0, category = "Biscuit", stock = 150),
                Product(name = "Crack Jack", price = 5.0, category = "Biscuit", stock = 100),
                Product(name = "Gudde", price = 5.0, category = "Biscuit", stock = 100),
                Product(name = "Cream Wala Biscuit", price = 5.0, category = "Biscuit", stock = 80),
                Product(name = "Monaco", price = 5.0, category = "Biscuit", stock = 100),
                Product(name = "Toast", price = 5.0, category = "Biscuit", stock = 50),

                // Grocery
                Product(name = "Lal Mirch", price = 10.0, category = "Grocery", stock = 120),
                Product(name = "Haldi", price = 10.0, category = "Grocery", stock = 120),
                Product(name = "Premium Sooji", price = 35.0, category = "Grocery", stock = 40),
                Product(name = "Vatan Chai Small Packet", price = 10.0, category = "Grocery", stock = 150),
                Product(name = "Vatan Chai", price = 80.0, category = "Grocery", stock = 30),
                Product(name = "Besan Bhajiya Lot", price = 60.0, category = "Grocery", stock = 30),
                Product(name = "Rice Poha", price = 40.0, category = "Grocery", stock = 45),

                // Soap
                Product(name = "Shanti Dabur Amla", price = 20.0, category = "Soap", stock = 60),
                Product(name = "Santoor Sabun", price = 10.0, category = "Soap", stock = 100),
                Product(name = "Kapde Dhone Ka Sabun", price = 10.0, category = "Soap", stock = 100),

                // Toothpaste
                Product(name = "Anchor Colgate", price = 10.0, category = "Toothpaste", stock = 50),
                Product(name = "Brush", price = 10.0, category = "Toothpaste", stock = 100),

                // Chips
                Product(name = "Chips Wafer", price = 5.0, category = "Chips", stock = 200)
            )
            productDao.insertAll(initialProducts)
        }
    }
}
