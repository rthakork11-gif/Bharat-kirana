package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BillDao {
    @Query("SELECT * FROM bills ORDER BY timestamp DESC")
    fun getAllBills(): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE timestamp >= :start AND timestamp <= :end ORDER BY timestamp DESC")
    fun getBillsByDateRange(start: Long, end: Long): Flow<List<Bill>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBill(bill: Bill): Long

    @Delete
    suspend fun deleteBill(bill: Bill)
}
