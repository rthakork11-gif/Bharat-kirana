package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

data class BillItem(
    val productName: String,
    val category: String,
    val price: Double,
    val quantity: Int,
    val total: Double
)

@Entity(tableName = "bills")
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerName: String,
    val customerMobile: String,
    val timestamp: Long = System.currentTimeMillis(),
    val itemsJson: String, // JSON serialization of List<BillItem>
    val grandTotal: Double
)
