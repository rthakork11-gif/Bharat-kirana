package com.example.util

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import com.example.data.Bill
import com.example.data.BillItem
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object PrinterHelper {

    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    // Get paired bluetooth devices securely
    @SuppressLint("MissingPermission")
    fun getPairedDevices(): List<BluetoothDevice> {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        if (!adapter.isEnabled) return emptyList()
        return try {
            adapter.bondedDevices.toList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Build the plain monospaced text for thermal roll (32 chars wide for 58mm printer)
    fun buildThermalReceiptText(bill: Bill, items: List<BillItem>): String {
        val sb = StringBuilder()
        val dateFormat = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault())
        val dateStr = dateFormat.format(Date(bill.timestamp))

        sb.append("      BHARAT KIRANA SHOP      \n")
        sb.append("     ====================     \n")
        sb.append("Bill No: #${bill.id}\n")
        sb.append("Date: $dateStr\n")
        sb.append("Cust: ${bill.customerName.take(20)}\n")
        if (bill.customerMobile.isNotEmpty()) {
            sb.append("Mob: +91-${bill.customerMobile}\n")
        }
        sb.append("--------------------------------\n")
        sb.append("Item             Qty  Rate  Total\n")
        sb.append("--------------------------------\n")
        
        for (item in items) {
            val name = if (item.productName.length > 15) item.productName.take(13) + ".." else item.productName.padEnd(15)
            val qty = item.quantity.toString().padStart(3)
            val rate = String.format(Locale.US, "%.0f", item.price).padStart(4)
            val total = String.format(Locale.US, "%.0f", item.total).padStart(6)
            sb.append("$name $qty $rate $total\n")
        }
        sb.append("--------------------------------\n")
        val grandTotalStr = "Grand Total: INR ${String.format(Locale.US, "%.2f", bill.grandTotal)}"
        sb.append(grandTotalStr.padStart(32) + "\n")
        sb.append("\n")
        sb.append("   Dhanyawad! Visit Again!   \n")
        sb.append("      Power By Bharat App     \n")
        sb.append("\n\n\n")
        return sb.toString()
    }

    // Connect and send real print command to chosen Bluetooth printer
    @SuppressLint("MissingPermission")
    fun printToBluetoothDevice(
        device: BluetoothDevice,
        bill: Bill,
        items: List<BillItem>,
        onResult: (Boolean, String) -> Unit
    ) {
        Thread {
            var socket: BluetoothSocket? = null
            var outStream: OutputStream? = null
            try {
                // Open RFCOMM connection socket
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket.connect()
                outStream = socket.outputStream

                // ESC/POS Initialization Commands
                val initPrinter = byteArrayOf(0x1B, 0x40) // ESC @
                val alignCenter = byteArrayOf(0x1B, 0x61, 0x01) // ESC a 1
                val alignLeft = byteArrayOf(0x1B, 0x61, 0x00) // ESC a 0
                val boldOn = byteArrayOf(0x1B, 0x45, 0x01) // ESC E 1
                val boldOff = byteArrayOf(0x1B, 0x45, 0x00) // ESC E 0
                val doubleSizeOn = byteArrayOf(0x1D, 0x21, 0x11) // GS ! 17 (Double Height + Width)
                val doubleSizeOff = byteArrayOf(0x1D, 0x21, 0x00) // GS ! 0

                val dateFormat = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault())
                val dateStr = dateFormat.format(Date(bill.timestamp))

                // Write Header (Bold, Centered, Double Size)
                outStream.write(initPrinter)
                outStream.write(alignCenter)
                outStream.write(doubleSizeOn)
                outStream.write("BHARAT KIRANA\n".toByteArray(charset("GBK")))
                outStream.write(doubleSizeOff)
                outStream.write("--------------------------------\n".toByteArray())
                
                // Details (Left aligned, Bold off)
                outStream.write(alignLeft)
                outStream.write("Bill No: #${bill.id}\n".toByteArray())
                outStream.write("Date: $dateStr\n".toByteArray())
                outStream.write("Customer: ${bill.customerName}\n".toByteArray())
                if (bill.customerMobile.isNotEmpty()) {
                    outStream.write("Mobile: +91-${bill.customerMobile}\n".toByteArray())
                }
                outStream.write("--------------------------------\n".toByteArray())

                // Table Items
                outStream.write("Item             Qty  Rate  Total\n".toByteArray())
                outStream.write("--------------------------------\n".toByteArray())
                for (item in items) {
                    val name = if (item.productName.length > 15) item.productName.take(13) + ".." else item.productName.padEnd(15)
                    val qty = item.quantity.toString().padStart(3)
                    val rate = String.format(Locale.US, "%.0f", item.price).padStart(4)
                    val total = String.format(Locale.US, "%.0f", item.total).padStart(6)
                    outStream.write("$name $qty $rate $total\n".toByteArray(charset("GBK")))
                }
                outStream.write("--------------------------------\n".toByteArray())

                // Grand Total (Bold, aligned right)
                outStream.write(alignCenter)
                outStream.write(boldOn)
                val totalStr = "TOTAL: INR ${String.format(Locale.US, "%.2f", bill.grandTotal)}\n"
                outStream.write(totalStr.toByteArray())
                outStream.write(boldOff)

                // Footer (Centered)
                outStream.write(alignCenter)
                outStream.write("\nDhanyawad! Please Visit Again!\n\n\n\n\n".toByteArray(charset("GBK")))

                // Feed & Cut (if printer supports)
                outStream.write(byteArrayOf(0x1D, 0x56, 0x41, 0x03)) // GS V A 3 (feed paper and cut)

                outStream.flush()
                onResult(true, "प्रिंट सफल! (Printed successfully)")
            } catch (e: IOException) {
                onResult(false, "प्रिंटर कनेक्शन एरर: ${e.message}")
            } finally {
                try {
                    outStream?.close()
                    socket?.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }.start()
    }
}
