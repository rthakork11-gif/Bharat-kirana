package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.Bill
import com.example.data.BillItem
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfHelper {

    fun generateBillPdf(
        context: Context,
        bill: Bill,
        items: List<BillItem>
    ): File? {
        val pdfDocument = PdfDocument()
        
        // A4 size: 595 x 842 points
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint()
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            isAntiAlias = true
        }

        val dateFormat = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault())
        val dateString = dateFormat.format(Date(bill.timestamp))

        var y = 50f
        val leftMargin = 45f
        val rightMargin = 550f

        // Draw Header Border Banner in Teal
        paint.color = 0xFF007A65.toInt() // Kirana Teal
        canvas.drawRect(leftMargin, y, rightMargin, y + 60, paint)

        // Title text on banner
        textPaint.apply {
            color = Color.WHITE
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("भारत किराना (BHARAT KIRANA)", leftMargin + 20, y + 38, textPaint)

        textPaint.apply {
            color = Color.WHITE
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        canvas.drawText("थोक एवं चिल्हर किराना व्यापारी | Billing Invoice", leftMargin + 20, y + 54, textPaint)

        y += 85f

        // Draw Bill details (ID, Date)
        textPaint.apply {
            color = 0xFF1E293B.toInt()
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("बिल नंबर (Bill No): #${bill.id}", leftMargin, y, textPaint)

        textPaint.apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val dateText = "दिनांक (Date): $dateString"
        canvas.drawText(dateText, rightMargin - textPaint.measureText(dateText), y, textPaint)

        y += 22f

        // Customer details
        canvas.drawText("ग्राहक का नाम (Customer): ${bill.customerName}", leftMargin, y, textPaint)
        if (bill.customerMobile.isNotEmpty()) {
            val mobText = "मोबाइल (Mobile): +91-${bill.customerMobile}"
            canvas.drawText(mobText, rightMargin - textPaint.measureText(mobText), y, textPaint)
        }

        y += 20f

        // Draw border line
        paint.color = Color.LTGRAY
        paint.strokeWidth = 1f
        canvas.drawLine(leftMargin, y, rightMargin, y, paint)

        y += 25f

        // Table Header
        paint.color = 0xFFF1F5F9.toInt() // Light Gray Background
        canvas.drawRect(leftMargin, y - 16, rightMargin, y + 10, paint)

        textPaint.apply {
            color = 0xFF0F172A.toInt()
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 11f
        }
        
        canvas.drawText("सामान (Item Name)", leftMargin + 10, y, textPaint)
        canvas.drawText("दर (Rate)", leftMargin + 250, y, textPaint)
        canvas.drawText("मात्रा (Qty)", leftMargin + 350, y, textPaint)
        
        val totalHeader = "कुल मूल्य (Total)"
        canvas.drawText(totalHeader, rightMargin - textPaint.measureText(totalHeader) - 10, y, textPaint)

        y += 20f

        // Table Rows
        textPaint.apply {
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textSize = 11f
        }

        for (item in items) {
            // Draw separator line
            paint.color = 0xFFE2E8F0.toInt()
            canvas.drawLine(leftMargin, y - 10, rightMargin, y - 10, paint)

            canvas.drawText(item.productName, leftMargin + 10, y, textPaint)
            canvas.drawText("₹${String.format(Locale.getDefault(), "%.2f", item.price)}", leftMargin + 250, y, textPaint)
            canvas.drawText("${item.quantity}", leftMargin + 350, y, textPaint)

            val itemTotalText = "₹${String.format(Locale.getDefault(), "%.2f", item.total)}"
            canvas.drawText(itemTotalText, rightMargin - textPaint.measureText(itemTotalText) - 10, y, textPaint)

            y += 22f

            // Handle page overflow safely
            if (y > 750) {
                break
            }
        }

        // Draw grand total line
        paint.color = 0xFF007A65.toInt()
        paint.strokeWidth = 1.5f
        canvas.drawLine(leftMargin, y - 5, rightMargin, y - 5, paint)

        y += 22f

        // Draw Grand Total Box in Saffron Orange Accent
        paint.color = 0xFFFEF3C7.toInt() // Light Orange Amber Tonal
        canvas.drawRect(leftMargin + 220, y - 16, rightMargin, y + 15, paint)

        textPaint.apply {
            color = 0xFFB45309.toInt() // Amber Dark text
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 13f
        }
        canvas.drawText("कुल योग (Grand Total):", leftMargin + 235, y, textPaint)

        val finalTotalText = "₹${String.format(Locale.getDefault(), "%.2f", bill.grandTotal)}"
        canvas.drawText(finalTotalText, rightMargin - textPaint.measureText(finalTotalText) - 15, y, textPaint)

        y += 45f

        // Footer note
        textPaint.apply {
            color = 0xFF64748B.toInt()
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        }
        val footerText = "धन्यवाद! कृपया दोबारा पधारें। | Thank you! Please visit again."
        canvas.drawText(footerText, (595 - textPaint.measureText(footerText)) / 2, y, textPaint)

        val sysText = "Generated Offline by Bharat Kirana Billing App"
        canvas.drawText(sysText, (595 - textPaint.measureText(sysText)) / 2, y + 15, textPaint)

        pdfDocument.finishPage(page)

        // Save PDF file in application cache directory
        val file = File(context.cacheDir, "Bharat_Kirana_Bill_${bill.id}.pdf")
        return try {
            val fos = FileOutputStream(file)
            pdfDocument.writeTo(fos)
            fos.close()
            pdfDocument.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            pdfDocument.close()
            null
        }
    }

    fun sharePdf(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "com.aistudio.kiranabilling.bshqtz.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        val chooser = Intent.createChooser(intent, "बिल भेजें (Share Invoice PDF)")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun sharePdfViaWhatsApp(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "com.aistudio.kiranabilling.bshqtz.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            setPackage("com.whatsapp") // Target WhatsApp directly if installed
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to standard share chooser if WhatsApp is not installed
            val chooser = Intent.createChooser(intent, "व्हाट्सएप पर साझा करें (Share via WhatsApp)")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        }
    }
}
