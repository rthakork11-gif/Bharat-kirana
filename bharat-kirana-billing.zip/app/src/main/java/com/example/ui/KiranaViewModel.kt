package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.example.data.AppDatabase
import com.example.data.Bill
import com.example.data.BillItem
import com.example.data.KiranaRepository
import com.example.data.Product
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class KiranaViewModel(
    application: Application,
    private val repository: KiranaRepository
) : AndroidViewModel(application) {

    // App Preferences / Navigation State
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    private val _currentTab = MutableStateFlow(0) // 0: Billing, 1: Stock, 2: Reports
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    // Customer Info
    private val _customerName = MutableStateFlow("")
    val customerName: StateFlow<String> = _customerName.asStateFlow()

    private val _customerMobile = MutableStateFlow("")
    val customerMobile: StateFlow<String> = _customerMobile.asStateFlow()

    // Billing Search & Select
    private val _billingSearchQuery = MutableStateFlow("")
    val billingSearchQuery: StateFlow<String> = _billingSearchQuery.asStateFlow()

    private val _billingSelectedCategory = MutableStateFlow("All")
    val billingSelectedCategory: StateFlow<String> = _billingSelectedCategory.asStateFlow()

    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    private val _enteredPrice = MutableStateFlow(0.0)
    val enteredPrice: StateFlow<Double> = _enteredPrice.asStateFlow()

    private val _enteredQuantity = MutableStateFlow(1)
    val enteredQuantity: StateFlow<Int> = _enteredQuantity.asStateFlow()

    // Auto-calculated item total: price * quantity
    val enteredTotal: StateFlow<Double> = combine(_enteredPrice, _enteredQuantity) { price, qty ->
        price * qty
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Current Bill Items (un-saved)
    private val _billItems = MutableStateFlow<List<BillItem>>(emptyList())
    val billItems: StateFlow<List<BillItem>> = _billItems.asStateFlow()

    // Grand Total of current bill
    val billGrandTotal: StateFlow<Double> = _billItems.combine(_billItems) { items, _ ->
        items.sumOf { it.total }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Stock Management Fields
    private val _stockSearchQuery = MutableStateFlow("")
    val stockSearchQuery: StateFlow<String> = _stockSearchQuery.asStateFlow()

    private val _editingProduct = MutableStateFlow<Product?>(null)
    val editingProduct: StateFlow<Product?> = _editingProduct.asStateFlow()

    private val _isAddingNewProduct = MutableStateFlow(false)
    val isAddingNewProduct: StateFlow<Boolean> = _isAddingNewProduct.asStateFlow()

    // Feedback message (TOAST-like banner)
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    // Database Flows
    val allProducts: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBills: StateFlow<List<Bill>> = repository.allBills
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Products for Billing Screen
    val filteredBillingProducts: StateFlow<List<Product>> = combine(
        allProducts,
        _billingSearchQuery,
        _billingSelectedCategory
    ) { products, query, category ->
        products.filter { product ->
            val matchesQuery = product.name.contains(query, ignoreCase = true) ||
                    product.category.contains(query, ignoreCase = true)
            val matchesCategory = category == "All" || product.category.equals(category, ignoreCase = true)
            matchesQuery && matchesCategory
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Products for Stock Screen
    val filteredStockProducts: StateFlow<List<Product>> = combine(
        allProducts,
        _stockSearchQuery
    ) { products, query ->
        products.filter { product ->
            product.name.contains(query, ignoreCase = true) ||
                    product.category.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Moshi Serializer for Bills
    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val type = Types.newParameterizedType(List::class.java, BillItem::class.java)
    private val listAdapter = moshi.adapter<List<BillItem>>(type)

    init {
        // Prepopulate on startup
        viewModelScope.launch {
            repository.prepopulateIfEmpty()
        }
    }

    // Toggle Preferences
    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun setTab(tabIndex: Int) {
        _currentTab.value = tabIndex
    }

    fun showMessage(message: String) {
        _statusMessage.value = message
    }

    fun clearMessage() {
        _statusMessage.value = null
    }

    // Customer Field Setters
    fun updateCustomerName(name: String) {
        _customerName.value = name
    }

    fun updateCustomerMobile(mobile: String) {
        // Simple numeric/length validation wrapper
        _customerMobile.value = mobile.filter { it.isDigit() }.take(10)
    }

    // Billing Search & Filters
    fun updateBillingSearch(query: String) {
        _billingSearchQuery.value = query
    }

    fun selectBillingCategory(category: String) {
        _billingSelectedCategory.value = category
    }

    // Select Product from Dropdown Picker
    fun selectProduct(product: Product?) {
        _selectedProduct.value = product
        if (product != null) {
            _enteredPrice.value = product.price
            _enteredQuantity.value = 1
        } else {
            _enteredPrice.value = 0.0
            _enteredQuantity.value = 1
        }
    }

    fun updateEnteredPrice(price: Double) {
        _enteredPrice.value = price
    }

    fun updateEnteredQuantity(qty: Int) {
        if (qty >= 1) {
            _enteredQuantity.value = qty
        }
    }

    // Add selected item to current active Bill
    fun addBillItem() {
        val product = _selectedProduct.value
        val price = _enteredPrice.value
        val qty = _enteredQuantity.value

        if (product == null) {
            showMessage("कृपया पहले कोई सामान चुनें (Please select a product first)")
            return
        }
        if (price <= 0) {
            showMessage("कीमत 0 से अधिक होनी चाहिए (Price must be greater than 0)")
            return
        }

        // Check stock availability
        if (product.stock < qty) {
            showMessage("चेतावनी: पर्याप्त स्टॉक नहीं है! केवल ${product.stock} उपलब्ध हैं। (Insufficient Stock!)")
        }

        val newItem = BillItem(
            productName = product.name,
            category = product.category,
            price = price,
            quantity = qty,
            total = price * qty
        )

        // Add item or merge if item with same name exists
        val currentList = _billItems.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.productName.equals(newItem.productName, ignoreCase = true) }

        if (existingIndex >= 0) {
            val existingItem = currentList[existingIndex]
            val mergedQty = existingItem.quantity + newItem.quantity
            currentList[existingIndex] = existingItem.copy(
                quantity = mergedQty,
                total = existingItem.price * mergedQty
            )
        } else {
            currentList.add(newItem)
        }

        _billItems.value = currentList
        showMessage("${product.name} जोड़ा गया (Added to bill)")

        // Deduct local view product stock temporarily or just clear selection
        selectProduct(null)
    }

    // Remove single item from current bill list
    fun removeBillItem(item: BillItem) {
        val currentList = _billItems.value.toMutableList()
        currentList.remove(item)
        _billItems.value = currentList
        showMessage("${item.productName} हटाया गया (Removed from bill)")
    }

    // Clear entire unsaved bill
    fun clearBill() {
        _billItems.value = emptyList()
        _customerName.value = ""
        _customerMobile.value = ""
        selectProduct(null)
        showMessage("बिल साफ़ किया गया (Bill cleared)")
    }

    // Save Bill to local SQLite database
    fun saveBill(onSaved: (Bill) -> Unit = {}) {
        val name = _customerName.value.trim()
        val mobile = _customerMobile.value.trim()
        val items = _billItems.value
        val total = billGrandTotal.value

        if (items.isEmpty()) {
            showMessage("बिल खाली है! सामान जोड़ें। (Bill is empty!)")
            return
        }

        viewModelScope.launch {
            try {
                // Compile items list as JSON string
                val itemsJson = listAdapter.toJson(items) ?: "[]"
                val newBill = Bill(
                    customerName = name.ifEmpty { "ग्राहक (Customer)" },
                    customerMobile = mobile,
                    timestamp = System.currentTimeMillis(),
                    itemsJson = itemsJson,
                    grandTotal = total
                )

                val id = repository.insertBill(newBill)

                // Update real stock counts in database
                for (item in items) {
                    val dbProduct = allProducts.value.find { it.name.equals(item.productName, ignoreCase = true) }
                    if (dbProduct != null) {
                        val newStock = (dbProduct.stock - item.quantity).coerceAtLeast(0)
                        repository.updateProduct(dbProduct.copy(stock = newStock))
                    }
                }

                showMessage("बिल नंबर #$id सुरक्षित किया गया! (Bill saved!)")
                onSaved(newBill.copy(id = id.toInt()))
                clearBill() // Reset UI
            } catch (e: Exception) {
                showMessage("बिल सुरक्षित करने में विफल: ${e.message}")
            }
        }
    }

    // Stock Management Actions
    fun updateStockSearch(query: String) {
        _stockSearchQuery.value = query
    }

    fun startEditingProduct(product: Product?) {
        _editingProduct.value = product
        _isAddingNewProduct.value = false
    }

    fun startAddingProduct() {
        _editingProduct.value = null
        _isAddingNewProduct.value = true
    }

    fun cancelProductEdit() {
        _editingProduct.value = null
        _isAddingNewProduct.value = false
    }

    fun saveProduct(name: String, category: String, price: Double, stock: Int) {
        if (name.isBlank() || category.isBlank()) {
            showMessage("नाम और श्रेणी आवश्यक हैं (Name and Category are required)")
            return
        }
        if (price <= 0) {
            showMessage("कीमत सही होनी चाहिए (Price must be positive)")
            return
        }

        viewModelScope.launch {
            try {
                val currentEditing = _editingProduct.value
                if (currentEditing != null) {
                    // Update
                    val updated = currentEditing.copy(
                        name = name.trim(),
                        category = category.trim(),
                        price = price,
                        stock = stock
                    )
                    repository.updateProduct(updated)
                    showMessage("सामान अपडेट किया गया (Product updated)")
                } else {
                    // Insert new
                    val newProduct = Product(
                        name = name.trim(),
                        category = category.trim(),
                        price = price,
                        stock = stock
                    )
                    repository.insertProduct(newProduct)
                    showMessage("नया सामान जोड़ा गया (New product added)")
                }
                cancelProductEdit()
            } catch (e: Exception) {
                showMessage("सहेजने में विफल: ${e.message}")
            }
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            try {
                repository.deleteProduct(product)
                showMessage("${product.name} हटाया गया (Deleted)")
                cancelProductEdit()
            } catch (e: Exception) {
                showMessage("हटाने में विफल: ${e.message}")
            }
        }
    }

    // Helper functions for sales calculations
    fun getBillItemsList(bill: Bill): List<BillItem> {
        return try {
            listAdapter.fromJson(bill.itemsJson) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // Factory companion according to standard Android architecture
    companion object {
        val Factory: ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
                val application = checkNotNull(extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY])
                val database = AppDatabase.getDatabase(application)
                val repository = KiranaRepository(database.productDao(), database.billDao())
                return KiranaViewModel(application, repository) as T
            }
        }
    }
}
