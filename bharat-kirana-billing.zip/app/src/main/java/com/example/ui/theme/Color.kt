package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val KiranaPrimary = Color(0xFF007A65) // Emerald Teal (trustworthy, offline/billing, whatsapp-ready)
val KiranaSecondary = Color(0xFFE58F1A) // Warm Amber/Saffron (festive, premium touch)
val KiranaTertiary = Color(0xFF2E5B88) // Soft Navy
val KiranaBackgroundLight = Color(0xFFF8FAFC) // Slate Ice White
val KiranaSurfaceLight = Color(0xFFFFFFFF)

// Dark Theme Colors
val KiranaPrimaryDark = Color(0xFF14B8A6) // Bright Teal
val KiranaSecondaryDark = Color(0xFFF59E0B) // Bright Amber
val KiranaTertiaryDark = Color(0xFF38BDF8) // Soft Sky Blue
val KiranaBackgroundDark = Color(0xFF0F172A) // Sleek Slate Slate Blue (very dark charcoal)
val KiranaSurfaceDark = Color(0xFF1E293B) // Layered dark slate card background

